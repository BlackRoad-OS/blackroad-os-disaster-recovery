# Debug Mode Pack (Redaction + Structured Logs + Console)

- **Redaction utils**: masks tokens, JWTs, and common secret fields.
- **Structured logs**: `pino` logger with safe `logSafe()` helper.
- **HTTP probes**: request/response middleware (Express) + fetch probe.
- **Toggleable Debug Console**: tiny React component you can drop in, toggled via localStorage.

## Quickstart
```bash
pnpm i
pnpm run dev   # starts an Express dev server on :7070
curl -XPOST localhost:7070/echo -H 'content-type: application/json' -d '{"token":"hf_12345","hello":"world"}'
```

### In the browser (React)
```tsx
import { DebugConsole, brLog } from './client/DebugConsole';

function App(){
  return <>
    <DebugConsole />
    <button onClick={()=> brLog('info','clicked',{ n: Math.random() })}>log</button>
  </>;
}
```

### In Node server
```ts
import { httpLogger, probeRequest, probeResponse } from './middleware/requestLogger';
app.use(httpLogger, probeRequest, probeResponse);
```

Tune patterns in `src/log/redactor.ts` for your environment.
