import type { Request, Response, NextFunction } from 'express';
import pinoHttp from 'pino-http';
import { logger } from '../log/logger.js';
import { redactObject } from '../log/redactor.js';

export const httpLogger = pinoHttp({ logger });

export function probeRequest(req: Request, _res: Response, next: NextFunction) {
  const snapshot = {
    method: req.method,
    url: req.url,
    query: req.query,
    headers: { ...req.headers, authorization: undefined, cookie: undefined },
    body: typeof req.body === 'object' ? redactObject(req.body) : undefined
  };
  logger.debug({ probe: snapshot }, 'http:request');
  next();
}

export function probeResponse(_req: Request, res: Response, next: NextFunction) {
  const original = res.json;
  (res as any).json = function (payload: any) {
    const redacted = redactObject(payload);
    logger.debug({ probe: { status: res.statusCode, body: redacted } }, 'http:response');
    return original.call(this, payload);
  };
  next();
}
