import React from 'react';

type Entry = { level: 'info'|'warn'|'error'|'debug'; message: string; data?: unknown; ts: number };

const storeKey = 'BR_DEBUG_ENABLED';

export function DebugConsole() {
  const [open, setOpen] = React.useState<boolean>(() => localStorage.getItem(storeKey) === '1');
  const [entries, setEntries] = React.useState<Entry[]>([]);

  React.useEffect(() => {
    const handler = (e: CustomEvent<Entry>) => setEntries((cur) => [...cur.slice(-199), e.detail]);
    window.addEventListener('br:log', handler as any);
    return () => window.removeEventListener('br:log', handler as any);
  }, []);

  return (
    <div style={{
      position: 'fixed', bottom: 12, right: 12, width: open ? 420 : 48,
      height: open ? 260 : 48, background: 'rgba(0,0,0,0.8)', color: 'white',
      borderRadius: 10, overflow: 'hidden', fontFamily: 'ui-monospace, monospace', zIndex: 9999
    }}>
      <button
        onClick={() => { const next = !open; setOpen(next); localStorage.setItem(storeKey, next ? '1':'0'); }}
        style={{ width: 48, height: 48, background: 'transparent', color: 'white', border: 'none', cursor: 'pointer' }}
        title="Toggle Debug"
      >{open ? '×' : '🐞'}</button>
      {open && (
        <div style={{ padding: 8, height: 212, overflow: 'auto' }}>
          {entries.map((e, i) => (
            <div key={i} style={{ opacity: 0.85 }}>
              <div><small>{new Date(e.ts).toLocaleTimeString()} · {e.level}</small></div>
              <pre style={{ whiteSpace: 'pre-wrap' }}>{e.message}</pre>
              {e.data && <pre style={{ whiteSpace: 'pre-wrap' }}>{JSON.stringify(e.data, null, 2)}</pre>}
              <hr style={{ borderColor: '#333' }}/>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// call this in app code to emit entries into the console
export function brLog(level: Entry['level'], message: string, data?: unknown) {
  const ev = new CustomEvent('br:log', { detail: { level, message, data, ts: Date.now() } });
  window.dispatchEvent(ev);
}
