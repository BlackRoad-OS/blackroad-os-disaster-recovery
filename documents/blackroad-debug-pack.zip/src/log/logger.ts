import pino from 'pino';
import { redactObject, RedactLevel } from './redactor';

const level = (process.env.LOG_LEVEL || 'info') as pino.LevelWithSilent;
const redactLevel = (process.env.DEBUG_REDACT_LEVEL || 'high') as RedactLevel;

export const logger = pino({
  level,
  base: undefined,
  redact: { paths: ['req.headers.authorization', 'req.headers.cookie', 'res.headers.set-cookie'], remove: false }
});

export function logSafe(msg: string, data?: unknown) {
  if (data) logger.info({ data: redactObject(data, redactLevel) }, msg);
  else logger.info(msg);
}
