const { redactString } = require('./redactor.ts'); // ts-node/tsx resolves ts; here it's a simple demo via tsx runtime

const sample = `
Authorization: Bearer sk-THISISAFAKEKEY
{
  "token": "hf_abcdEFGH1234567890",
  "password": "hunter2",
  "nested": { "jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ABC.DEF" }
}`;
console.log(require('fs').existsSync);
console.log(redactString(sample, 'high'));
