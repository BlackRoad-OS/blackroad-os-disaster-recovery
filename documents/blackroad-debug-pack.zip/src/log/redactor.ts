export type RedactLevel = 'none' | 'low' | 'high';

const patterns = {
  // Very basic patterns. Tune for your stack.
  apiKey: /(?:api[_-]?key|x-api-key)\s*[:=]\s*([A-Za-z0-9_\-]{16,})/gi,
  bearer: /bearer\s+[A-Za-z0-9._\-]{10,}/gi,
  skLike: /\bsk-[A-Za-z0-9]{16,}\b/g,
  hfLike: /\bhf_[A-Za-z0-9]{16,}\b/g,
  jwt: /\beyJ[a-zA-Z0-9_-]+?\.[a-zA-Z0-9_-]+?\.[a-zA-Z0-9_-]+?\b/g,
};

export function redactString(input: string, level: RedactLevel = 'high'): string {
  if (level === 'none') return input;
  let out = input;

  // Always redact obvious keys
  out = out.replace(patterns.apiKey, (m) => m.replace(/[:=]\s*.*/, ': [REDACTED]'));
  out = out.replace(patterns.skLike, '[REDACTED_KEY]');
  out = out.replace(patterns.hfLike, '[REDACTED_KEY]');
  out = out.replace(patterns.jwt, '[REDACTED_JWT]');
  out = out.replace(patterns.bearer, 'Bearer [REDACTED]');

  if (level === 'high') {
    // Scrub common secrets in JSON-like blobs
    out = out.replace(/"?(token|secret|password|pass|key)"?\s*:\s*"[^"]{4,}"/gi, (m) => {
      return m.replace(/:\s*".*"/, ': "[REDACTED]"');
    });
  }
  return out;
}

export function redactObject(obj: unknown, level: RedactLevel = 'high'): unknown {
  try {
    return JSON.parse(redactString(JSON.stringify(obj), level));
  } catch {
    return obj;
  }
}
