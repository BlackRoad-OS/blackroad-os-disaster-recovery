import { redactObject } from '../log/redactor.js';

export async function fetchProbe(input: RequestInfo, init?: RequestInit) {
  const started = Date.now();
  const reqInfo = typeof input === 'string' ? { url: input } : { url: (input as Request).url };
  const snapshot = { ...reqInfo, method: (init?.method || 'GET'), body: init?.body ? '[body]' : undefined };
  // eslint-disable-next-line no-console
  console.debug('probe:req', redactObject(snapshot));

  const res = await fetch(input as any, init);
  const elapsed = Date.now() - started;
  const clone = res.clone();
  let payload: any = null;
  try { payload = await clone.json(); } catch { payload = await clone.text(); }
  // eslint-disable-next-line no-console
  console.debug('probe:res', redactObject({ status: res.status, elapsed, body: payload }));
  return res;
}
