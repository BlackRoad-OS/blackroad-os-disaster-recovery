import express from 'express';
import { httpLogger, probeRequest, probeResponse } from '../middleware/requestLogger.js';
import { logSafe } from '../log/logger.js';

const app = express();
app.use(express.json());
app.use(httpLogger);
app.use(probeRequest);
app.use(probeResponse);

app.get('/health', (_req, res) => res.json({ ok: true }));

app.post('/echo', (req, res) => {
  logSafe('echo', { body: req.body, ts: Date.now() });
  res.json({ youSent: req.body });
});

const port = Number(process.env.PORT || 7070);
app.listen(port, () => console.log(`Debug server on http://localhost:${port}`));
